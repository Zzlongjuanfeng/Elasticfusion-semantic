vertex_feedback.vert index_map.frag
把每个vertex的位置/颜色/法向量/半径信息填入

fill_vertex.frag index_map.vert
从图像坐标系到世界坐标系到转换（rgb和depth转点云）
